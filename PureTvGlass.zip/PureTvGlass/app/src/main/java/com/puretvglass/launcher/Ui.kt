package com.puretvglass.launcher

import android.content.Context
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Helpers visuels : dégradés statiques et fonds « verre » légers (aucun flou dynamique). */
object Ui {
    val WALLPAPERS = listOf("Nuit bleue", "Aurore violette", "Minuit", "Océan")
    val THEMES = listOf("Bleu", "Violet", "Cyan")
    private val ACCENTS = intArrayOf(0xFF4C8DFF.toInt(), 0xFF8B6BFF.toInt(), 0xFF3CCBFF.toInt())

    fun accent(p: Prefs): Int = ACCENTS[p.theme.coerceIn(0, ACCENTS.size - 1)]

    fun wallpaper(p: Prefs): Drawable {
        if (!p.effects) return ColorDrawable(0xFF000000.toInt())
        val c = when (p.wallpaper) {
            1 -> intArrayOf(0xFF07050F.toInt(), 0xFF140A2E.toInt(), 0xFF2A0F4A.toInt())
            2 -> intArrayOf(0xFF000000.toInt(), 0xFF05080F.toInt(), 0xFF0A0F1C.toInt())
            3 -> intArrayOf(0xFF02070D.toInt(), 0xFF06203A.toInt(), 0xFF0A3A5C.toInt())
            else -> intArrayOf(0xFF05060F.toInt(), 0xFF0A1030.toInt(), 0xFF22156A.toInt())
        }
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, c)
    }

    fun shape(c: Context, fill: Int, stroke: Int, strokeDp: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = c.dp(radiusDp).toFloat()
            if (strokeDp > 0) setStroke(c.dp(strokeDp), stroke)
        }

    /** Fond à états : focus (liseré d'accent), sélectionné (teinte d'accent), repos. */
    fun states(c: Context, p: Prefs, card: Boolean, radius: Int): StateListDrawable {
        val a = accent(p)
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), shape(c, 0x40FFFFFF, a, 2, radius))
        sl.addState(intArrayOf(android.R.attr.state_selected), shape(c, (a and 0x00FFFFFF) or 0x55000000, a, 1, radius))
        sl.addState(intArrayOf(), shape(c, if (card) 0x1AFFFFFF else 0, 0x22FFFFFF, if (card) 1 else 0, radius))
        return sl
    }

    fun text(c: Context, s: String, size: Float, color: Int): TextView = TextView(c).apply {
        text = s
        textSize = size
        setTextColor(color)
        includeFontPadding = false
    }
}
