package com.puretvglass.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class SettingsActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var sv: ScrollView

    private val W = ViewGroup.LayoutParams.WRAP_CONTENT
    private val M = ViewGroup.LayoutParams.MATCH_PARENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        sv = ScrollView(this).apply { background = Ui.wallpaper(p); isVerticalScrollBarEnabled = false }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(36), 0, dp(36))
        }
        col.addView(Ui.text(this, "Paramètres", 30f, Color.WHITE).apply { setPadding(dp(4), 0, 0, dp(20)) })

        row(col, "Fond d'écran", { Ui.WALLPAPERS[p.wallpaper] }) {
            p.wallpaper = (p.wallpaper + 1) % Ui.WALLPAPERS.size
            sv.background = Ui.wallpaper(p)
        }
        row(col, "Thème (couleur d'accent)", { Ui.THEMES[p.theme] }) {
            p.theme = (p.theme + 1) % Ui.THEMES.size; recreate()
        }
        row(col, "Effets visuels (fond dégradé, animation du focus)", { if (p.effects) "Activés" else "Désactivés" }) {
            p.effects = !p.effects; recreate()
        }
        row(col, "Taille des icônes", { listOf("Petite", "Moyenne", "Grande")[p.iconSize] }) {
            p.iconSize = (p.iconSize + 1) % 3
        }
        row(col, "Afficher la date", { if (p.showDate) "Oui" else "Non" }) { p.showDate = !p.showDate }
        row(col, "Bouton Retour", { listOf("Retour à l'accueil", "Ne rien faire")[p.backMode] }) {
            p.backMode = (p.backMode + 1) % 2
        }
        row(col, "Gérer les applications favorites", null) { openMain(1, true) }
        row(col, "Modifier l'ordre des favoris", null) { openMain(2, false) }
        row(col, "Définir PURE TV GLASS comme écran d'accueil", null) {
            try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
            catch (e: Exception) {
                Toast.makeText(this, "Indisponible sur ce système : voir le README (commande adb).", Toast.LENGTH_LONG).show()
            }
        }
        col.addView(Ui.text(this, "PURE TV GLASS 1.0.0 · aucune donnée collectée · aucun accès réseau", 13f, 0xFF8892AA.toInt())
            .apply { setPadding(dp(4), dp(16), 0, 0) })

        sv.addView(col, FrameLayout.LayoutParams(dp(700), W, Gravity.CENTER_HORIZONTAL))
        setContentView(sv)
    }

    private fun openMain(page: Int, add: Boolean) {
        startActivity(Intent(this, MainActivity::class.java).putExtra("page", page).putExtra("add", add)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }

    private fun row(l: LinearLayout, title: String, value: (() -> String)?, act: () -> Unit) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(16), dp(22), dp(16))
            isFocusable = true
            background = Ui.states(this@SettingsActivity, p, true, 14)
        }
        r.addView(Ui.text(this, title, 18f, Color.WHITE), LinearLayout.LayoutParams(0, W, 1f))
        val v = Ui.text(this, value?.invoke() ?: "", 16f, 0xFFAEB8D0.toInt())
        r.addView(v)
        r.setOnClickListener { act(); v.text = value?.invoke() ?: "" }
        l.addView(r, LinearLayout.LayoutParams(M, W).apply { bottomMargin = dp(8) })
    }
}
