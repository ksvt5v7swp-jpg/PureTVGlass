package com.puretvglass.launcher

import android.content.Context

/** Préférences locales (SharedPreferences). Aucune donnée ne quitte l'appareil. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("pure_tv_glass", Context.MODE_PRIVATE)

    var wallpaper: Int
        get() = sp.getInt("wallpaper", 0)
        set(v) { sp.edit().putInt("wallpaper", v).apply() }
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var effects: Boolean
        get() = sp.getBoolean("effects", true)
        set(v) { sp.edit().putBoolean("effects", v).apply() }
    var iconSize: Int
        get() = sp.getInt("iconSize", 1)
        set(v) { sp.edit().putInt("iconSize", v).apply() }
    var showDate: Boolean
        get() = sp.getBoolean("showDate", true)
        set(v) { sp.edit().putBoolean("showDate", v).apply() }
    var backMode: Int
        get() = sp.getInt("backMode", 0)
        set(v) { sp.edit().putInt("backMode", v).apply() }

    val hasFavs: Boolean get() = sp.contains("favs")
    var favs: List<String>
        get() = (sp.getString("favs", "") ?: "").split("\n").filter { it.isNotEmpty() }
        set(v) { sp.edit().putString("favs", v.joinToString("\n")).apply() }
}
