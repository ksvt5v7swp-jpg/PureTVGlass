package com.puretvglass.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

private const val W = ViewGroup.LayoutParams.WRAP_CONTENT
private const val M = ViewGroup.LayoutParams.MATCH_PARENT

class AppEntry(val pkg: String, val label: String, val intent: Intent)

class MainActivity : Activity() {

    private lateinit var p: Prefs
    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var wifi: ImageView
    private val side = ArrayList<View>()
    private val tiles = HashMap<String, View>()
    private val io = Executors.newSingleThreadExecutor()
    private var icons: Map<String, Drawable> = emptyMap()
    private var apps: List<AppEntry> = emptyList()
    private var page = 0
    private var addMode = false
    private var moving: String? = null
    private var focusPkg: String? = null
    private var lookSig = ""

    companion object {
        // Applications proposées par défaut si elles sont installées
        val KNOWN = listOf(
            "com.netflix.ninja", "com.google.android.youtube.tv", "com.plexapp.android",
            "com.disney.disneyplus", "com.amazon.amazonvideo.livingroom", "tv.molotov.app",
            "com.spotify.tv.android"
        )
        private val LIVE_TV = listOf(
            "com.google.android.tv", "com.mediatek.wwtv.tvcenter", "com.sony.dtv.tvx", "org.droidtv.channels"
        )
        private val FILE_MANAGERS = listOf(
            "com.google.android.documentsui", "com.android.documentsui",
            "com.mi.android.globalFileexplorer", "com.estrongs.android.pop"
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        page = intent.getIntExtra("page", 0).coerceIn(0, 2)
        addMode = intent.getBooleanExtra("add", false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        page = intent.getIntExtra("page", 0).coerceIn(0, 2)
        addMode = intent.getBooleanExtra("add", false)
        moving = null
        if (::content.isInitialized) {
            showPage(page)
            side[page].requestFocus()
        }
    }

    override fun onResume() {
        super.onResume()
        val sig = "${p.wallpaper}${p.theme}${p.effects}${p.iconSize}${p.showDate}"
        if (sig != lookSig) {
            lookSig = sig
            setContentView(build())
            side[page].requestFocus()
        }
        updateWifi()
        loadApps()
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }

    // ---------- Construction de l'interface ----------

    private fun build(): View {
        side.clear()
        root = FrameLayout(this).apply { background = Ui.wallpaper(p) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(48), dp(28), dp(48), dp(24))
        }

        val header = FrameLayout(this)
        val cb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cb.addView(TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"
            textSize = 40f; setTextColor(Color.WHITE); includeFontPadding = false
        })
        cb.addView(TextClock(this).apply {
            format24Hour = "EEE d MMM yyyy"; format12Hour = "EEE d MMM yyyy"
            textSize = 16f; setTextColor(0xFFB8C0D4.toInt()); includeFontPadding = false
            visibility = if (p.showDate) View.VISIBLE else View.GONE
        })
        header.addView(cb)

        val st = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        wifi = ImageView(this).apply { setImageResource(R.drawable.ic_wifi); setColorFilter(Color.WHITE) }
        st.addView(wifi, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(16) })
        val gear = ImageView(this).apply {
            setImageResource(R.drawable.ic_settings); setColorFilter(Color.WHITE)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            isFocusable = true
            background = Ui.states(this@MainActivity, p, false, 20)
            setOnClickListener { openSettings() }
        }
        st.addView(gear, LinearLayout.LayoutParams(dp(44), dp(44)))
        header.addView(st, FrameLayout.LayoutParams(W, W, Gravity.END or Gravity.TOP))
        col.addView(header, LinearLayout.LayoutParams(M, W).apply { bottomMargin = dp(20) })

        val body = LinearLayout(this)
        val sb = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = Ui.shape(this@MainActivity, 0x14FFFFFF, 0x22FFFFFF, 1, 24)
        }
        sb.addView(navItem(R.drawable.ic_home, "Accueil", 0))
        sb.addView(navItem(R.drawable.ic_apps, "Applications", 1))
        sb.addView(navItem(R.drawable.ic_play, "Favoris", 2))
        sb.addView(navItem(R.drawable.ic_settings, "Paramètres", 3))
        sb.addView(navItem(R.drawable.ic_power, "Éteindre", 4))
        body.addView(sb, LinearLayout.LayoutParams(dp(230), W))
        content = FrameLayout(this)
        body.addView(content, LinearLayout.LayoutParams(0, M, 1f).apply { marginStart = dp(32) })
        col.addView(body, LinearLayout.LayoutParams(M, 0, 1f))
        root.addView(col, FrameLayout.LayoutParams(M, M))

        showPage(page)
        return root
    }

    private fun navItem(icon: Int, label: String, i: Int): View {
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            isFocusable = true
            background = Ui.states(this@MainActivity, p, false, 16)
        }
        v.addView(ImageView(this).apply { setImageResource(icon); setColorFilter(Color.WHITE) },
            LinearLayout.LayoutParams(dp(26), dp(26)))
        v.addView(Ui.text(this, label, 17f, 0xFFE6E9F2.toInt()),
            LinearLayout.LayoutParams(W, W).apply { marginStart = dp(16) })
        v.setOnClickListener {
            when (i) {
                0, 1, 2 -> { addMode = false; moving = null; showPage(i) }
                3 -> openSettings()
                else -> toast("Éteindre : maintenez le bouton Power de la télécommande (Android n'autorise pas un launcher à éteindre la TV).")
            }
        }
        side.add(v)
        return v
    }

    private fun showPage(n: Int) {
        page = n
        content.removeAllViews()
        tiles.clear()
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), 0, dp(8), dp(24))
        }
        when (n) {
            0 -> home(l)
            1 -> grid(l, apps, "Applications")
            else -> grid(l, favApps(), "Favoris")
        }
        sv.addView(l)
        content.addView(sv)
        side.forEachIndexed { i, v -> v.isSelected = (i == n) }
        focusPkg?.let { tiles[it]?.requestFocus() }
        focusPkg = null
    }

    private fun title(s: String) = Ui.text(this, s, 22f, Color.WHITE).apply {
        setPadding(dp(4), dp(8), 0, dp(12))
    }

    private fun hint(s: String) = Ui.text(this, s, 15f, 0xFFB8C0D4.toInt()).apply {
        setPadding(dp(4), dp(4), dp(4), dp(12))
    }

    private fun home(l: LinearLayout) {
        l.addView(title("Mes applications"))
        val fa = favApps()
        if (fa.isEmpty()) {
            l.addView(hint("Aucune application favorite. Ouvrez « Ajouter » ou « Applications » (appui long sur OK)."))
        } else {
            val h = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fa.forEach { r.addView(appTile(it)) }
            h.addView(r)
            l.addView(h)
        }
        l.addView(title("Raccourcis").apply { setPadding(dp(4), dp(28), 0, dp(12)) })
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r.addView(shortcut(R.drawable.ic_tv, "TV en direct") { liveTv() })
        r.addView(shortcut(R.drawable.ic_usb, "Lecteur USB") { files() })
        r.addView(shortcut(R.drawable.ic_folder, "Mes fichiers") { files() })
        r.addView(shortcut(R.drawable.ic_add, "Ajouter") {
            addMode = true
            focusPkg = apps.firstOrNull()?.pkg
            showPage(1)
        })
        l.addView(r)
    }

    private fun grid(l: LinearLayout, list: List<AppEntry>, t: String) {
        l.addView(title(t))
        if (addMode) l.addView(hint("Mode ajout : OK ajoute l'application aux favoris. Retour pour terminer."))
        else if (page == 1) l.addView(hint("Appui long sur OK : ajouter / retirer des favoris."))
        else l.addView(hint("Appui long sur OK : déplacer (◄ ►). Touche Menu : retirer des favoris."))
        if (list.isEmpty()) return
        val w = resources.displayMetrics.widthPixels - dp(48 * 2 + 230 + 32 + 16)
        val cols = (w / (dp(iconDp()) + dp(44))).coerceAtLeast(2)
        val g = GridLayout(this).apply { columnCount = cols }
        list.forEach { g.addView(appTile(it)) }
        l.addView(g)
    }

    private fun iconDp() = when (p.iconSize) { 0 -> 72; 2 -> 120; else -> 96 }

    private fun appTile(e: AppEntry): View {
        val s = dp(iconDp())
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            isFocusable = true
            tag = e.pkg
            background = Ui.states(this@MainActivity, p, false, 18)
        }
        val iv = ImageView(this).apply {
            setImageDrawable(icons[e.pkg])
            scaleType = ImageView.ScaleType.FIT_CENTER
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, o: Outline) {
                    o.setRoundRect(0, 0, view.width, view.height, dp(14).toFloat())
                }
            }
            clipToOutline = true
        }
        t.addView(iv, LinearLayout.LayoutParams(s, s))
        val tv = Ui.text(this, e.label, 13f, 0xFFE6E9F2.toInt()).apply {
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        }
        t.addView(tv, LinearLayout.LayoutParams(s, W).apply { topMargin = dp(8) })
        t.setOnClickListener { if (addMode) toggleFav(e.pkg, true) else launch(e.intent) }
        t.setOnLongClickListener { longClick(e); true }
        t.setOnFocusChangeListener { v, f ->
            if (p.effects) v.animate().scaleX(if (f) 1.07f else 1f).scaleY(if (f) 1.07f else 1f).setDuration(120).start()
        }
        if (e.pkg == moving) t.isSelected = true
        tiles[e.pkg] = t
        return t
    }

    private fun shortcut(icon: Int, label: String, act: () -> Unit): View {
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(14), dp(12), dp(14))
            isFocusable = true
            background = Ui.states(this@MainActivity, p, true, 18)
        }
        t.addView(ImageView(this).apply { setImageResource(icon); setColorFilter(0xFFDDE3F2.toInt()) },
            LinearLayout.LayoutParams(dp(34), dp(34)))
        t.addView(Ui.text(this, label, 14f, 0xFFE6E9F2.toInt()),
            LinearLayout.LayoutParams(W, W).apply { topMargin = dp(8) })
        t.setOnClickListener { act() }
        t.setOnFocusChangeListener { v, f ->
            if (p.effects) v.animate().scaleX(if (f) 1.06f else 1f).scaleY(if (f) 1.06f else 1f).setDuration(120).start()
        }
        val lp = LinearLayout.LayoutParams(dp(150), dp(96)).apply { marginEnd = dp(14) }
        t.layoutParams = lp
        return t
    }

    // ---------- Données ----------

    private fun favApps(): List<AppEntry> = p.favs.mapNotNull { f -> apps.firstOrNull { it.pkg == f } }

    private fun loadApps() {
        io.execute {
            val pm = packageManager
            val seen = LinkedHashMap<String, AppEntry>()
            val old = icons
            val fresh = HashMap<String, Drawable>()
            for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
                val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
                for (ri in pm.queryIntentActivities(q, 0)) {
                    val pkg = ri.activityInfo.packageName
                    if (pkg == packageName || seen.containsKey(pkg)) continue
                    val i = Intent(Intent.ACTION_MAIN).setClassName(pkg, ri.activityInfo.name)
                    seen[pkg] = AppEntry(pkg, ri.loadLabel(pm).toString(), i)
                    fresh[pkg] = old[pkg] ?: ri.loadIcon(pm)
                }
            }
            val list = seen.values.sortedBy { it.label.lowercase() }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                icons = fresh
                apps = list
                if (!p.hasFavs) p.favs = KNOWN.filter { k -> list.any { it.pkg == k } }
                showPage(page)
            }
        }
    }

    private fun toggleFav(pkg: String, onlyAdd: Boolean) {
        val f = p.favs.toMutableList()
        if (f.contains(pkg)) {
            if (onlyAdd) { toast("Déjà dans les favoris"); return }
            f.remove(pkg); toast("Retiré des favoris")
        } else {
            f.add(pkg); toast("Ajouté aux favoris")
        }
        p.favs = f
    }

    private fun longClick(e: AppEntry) {
        if (page == 1) {
            toggleFav(e.pkg, false)
        } else if (p.favs.contains(e.pkg)) {
            moving = e.pkg
            focusPkg = e.pkg
            toast("◄ ► pour déplacer · OK pour valider")
            showPage(page)
        }
    }

    private fun moveFav(pkg: String, d: Int) {
        val f = p.favs.toMutableList()
        val i = f.indexOf(pkg)
        val j = i + d
        if (i < 0 || j < 0 || j >= f.size) return
        val tmp = f[i]; f[i] = f[j]; f[j] = tmp
        p.favs = f
        focusPkg = pkg
        showPage(page)
    }

    // ---------- Actions ----------

    private fun launch(i: Intent) {
        try {
            startActivity(Intent(i).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        } catch (e: Exception) {
            toast("Impossible d'ouvrir cette application")
        }
    }

    private fun tryStart(i: Intent): Boolean = try {
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    private fun liveTv() {
        for (pkg in LIVE_TV) {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null && tryStart(i)) return
        }
        toast("Aucune application TV en direct trouvée sur cet appareil.")
    }

    private fun files() {
        for (pkg in FILE_MANAGERS) {
            if (tryStart(Intent("android.provider.action.BROWSE").setPackage(pkg))) return
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null && tryStart(i)) return
        }
        if (tryStart(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))) return
        toast("Aucun gestionnaire de fichiers trouvé. Installez-en un (ex. File Commander).")
    }

    private fun openSettings() = startActivity(Intent(this, SettingsActivity::class.java))

    private fun updateWifi() {
        val cm = getSystemService(ConnectivityManager::class.java)
        val nc = cm?.getNetworkCapabilities(cm.activeNetwork)
        val on = nc != null && (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
        wifi.alpha = if (on) 1f else 0.35f
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---------- Télécommande ----------

    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        if (ev.action == KeyEvent.ACTION_DOWN) {
            val m = moving
            if (m != null) {
                when (ev.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> { moveFav(m, -1); return true }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> { moveFav(m, 1); return true }
                    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> return true
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BACK -> {
                        if (ev.repeatCount == 0) { moving = null; focusPkg = m; showPage(page) }
                        return true
                    }
                }
            } else if (ev.keyCode == KeyEvent.KEYCODE_MENU && page != 1) {
                val pkg = currentFocus?.tag as? String
                if (pkg != null) { toggleFav(pkg, false); showPage(page) }
                return true
            }
        }
        return super.dispatchKeyEvent(ev)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Un launcher ne se ferme jamais.
        if (addMode) { addMode = false; showPage(page); return }
        if (p.backMode == 0 && page != 0) {
            showPage(0)
            side[0].requestFocus()
        }
    }
}
