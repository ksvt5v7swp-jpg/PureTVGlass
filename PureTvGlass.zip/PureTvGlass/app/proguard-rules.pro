# Aucune règle spécifique : pas de réflexion utilisée.
