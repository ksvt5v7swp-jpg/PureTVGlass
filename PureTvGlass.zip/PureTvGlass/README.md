# PURE TV GLASS

Launcher Android TV natif (Kotlin, **zéro dépendance externe**), minimaliste, sans publicité, sans télémétrie, sans permission réseau.

## État honnête du projet
Le code a été écrit **sans pouvoir être compilé ni testé** dans l'environnement de génération (pas d'accès réseau/SDK Android). Il n'a donc jamais tourné sur une TV. La première exécution du workflow GitHub Actions dira s'il compile ; si une erreur apparaît, copiez le log et elle sera corrigée.

## Fonctions
- Accueil : heure, date (masquable), Wi-Fi/Ethernet, menu latéral, « Mes applications », raccourcis.
- Détection automatique des apps installées (Leanback + Launcher) ; seules les apps présentes s'affichent (Netflix, YouTube, Plex, Disney+, Prime Video, Molotov, Spotify sont proposées en favoris par défaut si installées).
- Favoris : appui long sur OK dans *Applications* pour ajouter/retirer ; dans *Favoris* ou l'accueil, appui long sur OK puis ◄ ► pour déplacer, OK pour valider ; touche Menu pour retirer.
- Paramètres : fond (4), thème (3 couleurs), effets on/off, taille des icônes, date, comportement du bouton Retour, favoris, ordre, écran d'accueil par défaut.
- Préférences en local (SharedPreferences). Permission unique : `ACCESS_NETWORK_STATE`.

## Limites connues
- **Éteindre** : Android interdit à un launcher d'éteindre la TV ; le bouton affiche une indication.
- **TV en direct / Lecteur USB / Mes fichiers** : lancent l'app TV ou le gestionnaire de fichiers s'ils existent (liste de paquets connus), sinon un message s'affiche. Dépend du fabricant.
- Définir comme accueil par défaut : voir ci-dessous (souvent impossible via l'interface sur Google TV).

## Compiler
**GitHub (recommandé)** : poussez le dépôt sur `main` → onglet *Actions* → artefact `PureTvGlass-apk`. Pour une release : `git tag v1.0.0 && git push --tags` → APK dans *Releases*.

**Local** : JDK 17 + Android SDK 34 + Gradle 8.7 → `gradle assembleRelease` (ou ouvrir dans Android Studio). APK : `app/build/outputs/apk/release/app-release.apk` (signé avec la clé debug, usage personnel).

## Installer sur Android TV
1. TV : Paramètres → Préférences de l'appareil → À propos → appuyer 7× sur « Build » ; activer Options pour les développeurs → Débogage USB/réseau.
2. `adb connect IP_TV:5555` puis `adb install -r PureTvGlass.apk` (ou clé USB + gestionnaire de fichiers).
3. Lancer *PURE TV GLASS* depuis la liste des apps.
4. Accueil par défaut : essayer l'entrée des paramètres du launcher ; sinon  
   `adb shell cmd package set-home-activity "com.puretvglass.launcher/.MainActivity"`  
   (selon le modèle, l'accueil d'origine peut revenir au redémarrage ou nécessiter de désactiver le launcher d'origine).
